const { app, BrowserWindow, session } = require('electron');
const path = require('path');
function createWindow(){
 const win=new BrowserWindow({width:1280,height:800,minWidth:900,minHeight:600,backgroundColor:'#050a14',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,webviewTag:true}});
 win.loadFile(path.join(__dirname,'..','dist','index.html'));
}
app.whenReady().then(()=>{session.defaultSession.setPermissionRequestHandler((_webContents,permission,callback)=>callback(['camera','microphone'].includes(permission)));createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
