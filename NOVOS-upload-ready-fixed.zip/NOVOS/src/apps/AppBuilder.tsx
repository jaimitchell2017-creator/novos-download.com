import { useState, useCallback } from "react";
import { OSApp } from "../types";

const CATEGORIES = ["Productivity", "Entertainment", "Utilities", "Developer", "Social", "Education"];
const ICONS = ["🎮", "📊", "🎵", "📰", "🌤️", "🧮", "🎨", "📸", "🗺️", "💬", "📅", "🔬", "🏋️", "🍕", "✈️", "💰", "🎯", "🧩", "🤖", "⚡", "🌈", "🛸"];

const STARTER_HTML = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #050a14;
      color: #e2f0ff;
      font-family: 'Exo 2', 'Segoe UI', sans-serif;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .app {
      text-align: center;
      padding: 2rem;
    }
    h1 { font-size: 2rem; margin-bottom: 1rem; color: #00e5ff; }
    p { color: rgba(255,255,255,0.5); }
  </style>
</head>
<body>
  <div class="app">
    <h1>My App</h1>
    <p>Edit this code to build your app!</p>
  </div>
</body>
</html>`;

interface Props {
  onPublish: (app: OSApp) => void;
}

export default function AppBuilder({ onPublish }: Props) {
  const [tab, setTab] = useState<"create" | "ai">("create");
  const [appName, setAppName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Utilities");
  const [icon, setIcon] = useState("🤖");
  const [appType, setAppType] = useState<"html" | "url">("html");
  const [code, setCode] = useState(STARTER_HTML);
  const [externalUrl, setExternalUrl] = useState("");
  const [preview, setPreview] = useState(false);
  const [published, setPublished] = useState(false);

  // AI generation
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");

  const generateWithAI = useCallback(async () => {
    if (!aiPrompt.trim()) { setAiError("Please describe what you want to build"); return; }
    setAiError("");
    setAiLoading(true);

    try {
      // text.pollinations.ai GET — CORS-friendly, free, no key needed
      const shortPrompt = `Write a complete single-file HTML app. Dark theme bg #050a14 accent #00e5ff text #e2f0ff. Import Exo 2 from Google Fonts. Embed all CSS and JS. Output only raw HTML, no markdown. App to build: ${aiPrompt}`;
      const response = await fetch(
        `https://text.pollinations.ai/${encodeURIComponent(shortPrompt)}?model=openai&seed=${Date.now() % 9999}`,
        { method: "GET" }
      );

      if (!response.ok) {
        throw new Error(`AI service returned ${response.status} — please try again in a moment`);
      }

      const generated = await response.text();
      if (!generated?.trim()) throw new Error("AI returned an empty response — please try again");
      const stripped = generated.replace(/^```[\w]*\n?/gm, "").replace(/```\s*$/gm, "").trim();
      const htmlMatch = stripped.match(/<!DOCTYPE html>[\s\S]*/i) || stripped.match(/<html[\s\S]*/i);
      setCode(htmlMatch ? htmlMatch[0] : stripped);
      setTab("create");
      setAppType("html");
      if (aiPrompt && !appName) setAppName(aiPrompt.slice(0, 30));
    } catch (err) {
      setAiError(`Error: ${(err as Error).message}`);
    } finally {
      setAiLoading(false);
    }
  }, [aiPrompt, appName]);

  const handlePublish = () => {
    if (!appName.trim()) return;
    const id = `app-${Date.now()}`;
    const app: OSApp = {
      id,
      name: appName,
      icon,
      description: description || `A custom NovOS app`,
      category,
      builtIn: false,
      type: appType,
      code: appType === "html" ? code : undefined,
      url: appType === "url" ? externalUrl : undefined,
      installed: true,
      version: "1.0",
      author: "You",
      rating: 5,
      downloads: 0,
    };
    onPublish(app);
    setPublished(true);
    setTimeout(() => setPublished(false), 3000);
  };

  return (
    <div className="h-full flex flex-col text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
      {/* Header */}
      <div className="flex-shrink-0 px-6 py-4 border-b border-cyan-500/10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: "'Orbitron', sans-serif" }}>App Builder</h1>
            <p className="text-white/30 text-xs mt-0.5">Create and publish apps to the NovOS App Store</p>
          </div>
          {published && (
            <div className="px-4 py-2 rounded-xl bg-green-500/20 border border-green-500/30 text-green-400 text-sm animate-fade-in">
              ✓ Published to App Store!
            </div>
          )}
        </div>

        <div className="flex gap-1 mt-4">
          {[{ id: "create" as const, label: "✏️ Build" }, { id: "ai" as const, label: "🤖 AI Generate" }].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="px-4 py-1.5 rounded-xl text-sm font-medium transition-all"
              style={{
                background: tab === t.id ? "rgba(0,229,255,0.15)" : "transparent",
                color: tab === t.id ? "#00e5ff" : "rgba(255,255,255,0.4)",
                border: `1px solid ${tab === t.id ? "rgba(0,229,255,0.3)" : "transparent"}`,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex">
        {tab === "create" && (
          <>
            {/* Left: Form */}
            <div className="w-64 flex-shrink-0 border-r border-cyan-500/10 p-4 overflow-y-auto os-scrollbar space-y-4">
              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">App Name *</label>
                <input
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  placeholder="My App"
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-xl px-3 py-2 text-white/80 text-sm outline-none focus:border-cyan-400/40 transition-all placeholder-white/20"
                />
              </div>

              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">Icon</label>
                <div className="grid grid-cols-5 gap-1.5">
                  {ICONS.map((ic) => (
                    <button
                      key={ic}
                      onClick={() => setIcon(ic)}
                      className="w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all hover:scale-110"
                      style={{
                        background: icon === ic ? "rgba(0,229,255,0.2)" : "rgba(255,255,255,0.05)",
                        border: `1px solid ${icon === ic ? "rgba(0,229,255,0.5)" : "transparent"}`,
                      }}
                    >
                      {ic}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What does this app do?"
                  rows={3}
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-xl px-3 py-2 text-white/80 text-sm outline-none focus:border-cyan-400/40 transition-all placeholder-white/20 resize-none"
                />
              </div>

              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-xl px-3 py-2 text-white/80 text-sm outline-none focus:border-cyan-400/40 transition-all"
                  style={{ background: "rgba(5,15,35,0.8)" }}
                >
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">App Type</label>
                <div className="flex gap-2">
                  {(["html", "url"] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setAppType(t)}
                      className="flex-1 py-1.5 rounded-xl text-xs font-medium transition-all"
                      style={{
                        background: appType === t ? "rgba(0,229,255,0.15)" : "rgba(255,255,255,0.05)",
                        color: appType === t ? "#00e5ff" : "rgba(255,255,255,0.4)",
                        border: `1px solid ${appType === t ? "rgba(0,229,255,0.3)" : "transparent"}`,
                      }}
                    >
                      {t === "html" ? "HTML App" : "Web URL"}
                    </button>
                  ))}
                </div>
              </div>

              {appType === "url" && (
                <div>
                  <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">App URL</label>
                  <input
                    value={externalUrl}
                    onChange={(e) => setExternalUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-white/5 border border-cyan-500/20 rounded-xl px-3 py-2 text-white/80 text-sm outline-none focus:border-cyan-400/40 transition-all placeholder-white/20"
                  />
                </div>
              )}

              <button
                onClick={handlePublish}
                disabled={!appName.trim()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 text-white text-sm font-semibold disabled:opacity-40 hover:opacity-90 active:scale-95 transition-all"
              >
                🚀 Publish to App Store
              </button>
            </div>

            {/* Right: Code editor / preview */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-2 border-b border-cyan-500/10 flex-shrink-0">
                <div className="flex gap-1">
                  <button
                    onClick={() => setPreview(false)}
                    className="px-3 py-1 rounded-lg text-xs transition-all"
                    style={{
                      background: !preview ? "rgba(0,229,255,0.15)" : "transparent",
                      color: !preview ? "#00e5ff" : "rgba(255,255,255,0.4)",
                    }}
                  >
                    Code
                  </button>
                  <button
                    onClick={() => setPreview(true)}
                    className="px-3 py-1 rounded-lg text-xs transition-all"
                    style={{
                      background: preview ? "rgba(0,229,255,0.15)" : "transparent",
                      color: preview ? "#00e5ff" : "rgba(255,255,255,0.4)",
                    }}
                  >
                    Preview
                  </button>
                </div>
                {appType === "html" && !preview && (
                  <p className="text-white/20 text-xs ml-2">Write HTML, CSS and JavaScript</p>
                )}
              </div>

              {appType === "html" ? (
                !preview ? (
                  <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="flex-1 w-full bg-transparent p-4 text-cyan-300/80 text-xs outline-none resize-none os-scrollbar"
                    style={{ fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.6 }}
                    spellCheck={false}
                  />
                ) : (
                  <iframe
                    srcDoc={code}
                    className="flex-1 w-full border-0"
                    sandbox="allow-scripts allow-forms"
                    title="Preview"
                  />
                )
              ) : (
                <div className="flex-1 flex items-center justify-center text-white/30 p-8 text-center">
                  <div>
                    <div className="text-4xl mb-4">🔗</div>
                    <p className="text-sm">URL apps open the external site directly.</p>
                    <p className="text-xs mt-2">Enter the URL on the left and publish.</p>
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {tab === "ai" && (
          <div className="flex-1 overflow-y-auto os-scrollbar p-6">
            <div className="max-w-lg space-y-6">
              <div>
                <h2 className="text-lg font-bold mb-1" style={{ fontFamily: "'Orbitron', sans-serif" }}>AI App Generator</h2>
                <p className="text-white/40 text-sm">Describe any app and AI will write it for you instantly — completely free, no account or API key needed.</p>
              </div>

              <div className="glass-light rounded-xl px-4 py-3 flex items-center gap-3 border border-cyan-500/15">
                <span className="text-xl">⚡</span>
                <div>
                  <p className="text-cyan-400 text-xs font-semibold">Powered by Pollinations AI · GPT-4o</p>
                  <p className="text-white/30 text-[10px]">No sign-up, no cost, no limits</p>
                </div>
              </div>

              {/* Prompt */}
              <div>
                <label className="text-white/40 text-[10px] uppercase tracking-wider mb-1.5 block">What do you want to build?</label>
                <textarea
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g. A todo list app with drag and drop, dark theme, and local storage persistence"
                  rows={5}
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-2xl px-4 py-3 text-white/80 text-sm outline-none focus:border-cyan-400/40 transition-all placeholder-white/20 resize-none"
                />
              </div>

              {aiError && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs">
                  {aiError}
                </div>
              )}

              <button
                onClick={generateWithAI}
                disabled={aiLoading || !aiPrompt.trim()}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 text-white font-semibold text-sm disabled:opacity-40 hover:opacity-90 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {aiLoading ? (
                  <>
                    <span className="animate-spin">⟳</span>
                    Generating...
                  </>
                ) : (
                  <>🤖 Generate App Code</>
                )}
              </button>

              <div className="glass-light rounded-2xl p-4 space-y-2">
                <h3 className="text-white/60 text-xs font-semibold uppercase tracking-wider">Example Ideas</h3>
                {[
                  "A countdown timer with custom labels and sounds",
                  "A calculator with a futuristic holographic design",
                  "A random quote generator with categories",
                  "A simple drawing canvas with color picker",
                  "A weather dashboard (using a free API)",
                ].map((idea) => (
                  <button
                    key={idea}
                    onClick={() => setAiPrompt(idea)}
                    className="block w-full text-left text-white/40 text-xs hover:text-white/70 py-1 transition-colors"
                  >
                    → {idea}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
