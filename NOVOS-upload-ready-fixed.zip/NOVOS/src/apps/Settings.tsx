import { useState } from "react";
import { OSSettings, OSUser } from "../types";

const WALLPAPERS = [
  { id: "wallpaper-aurora", name: "Aurora", preview: "linear-gradient(135deg, #050a14, #006ec8, #7c3aed)" },
  { id: "wallpaper-nebula", name: "Nebula", preview: "linear-gradient(135deg, #020008, #7c3aed, #f0abfc)" },
  { id: "wallpaper-neon", name: "Neon Grid", preview: "linear-gradient(135deg, #050a14, #00e5ff, #7c3aed)" },
  { id: "wallpaper-matrix", name: "Matrix", preview: "linear-gradient(135deg, #000a00, #005028, #00e070)" },
  { id: "wallpaper-sunset", name: "Cosmic Sunset", preview: "linear-gradient(135deg, #0d0020, #500020, #200010)" },
  { id: "wallpaper-deep", name: "Deep Space", preview: "linear-gradient(135deg, #000510, #001030, #000820)" },
];

const ACCENT_COLORS = [
  { color: "#00e5ff", name: "Cyan" },
  { color: "#7c3aed", name: "Violet" },
  { color: "#f0abfc", name: "Pink" },
  { color: "#10b981", name: "Emerald" },
  { color: "#f59e0b", name: "Amber" },
  { color: "#ef4444", name: "Red" },
  { color: "#3b82f6", name: "Blue" },
  { color: "#ffffff", name: "White" },
];

interface Props {
  settings: OSSettings;
  user: OSUser;
  onUpdate: (s: OSSettings) => void;
  onLogout: () => void;
}

export default function Settings({ settings, user, onUpdate, onLogout }: Props) {
  const [tab, setTab] = useState<"appearance" | "system" | "about">("appearance");
  const [localName, setLocalName] = useState(settings.userName);

  const update = (patch: Partial<OSSettings>) => onUpdate({ ...settings, ...patch });

  const tabs = [
    { id: "appearance" as const, label: "Appearance", icon: "🎨" },
    { id: "system" as const, label: "System", icon: "⚙️" },
    { id: "about" as const, label: "About", icon: "ℹ️" },
  ];

  return (
    <div className="h-full flex text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>
      {/* Sidebar */}
      <div className="w-48 flex-shrink-0 border-r border-cyan-500/10 p-4 flex flex-col gap-1">
        <p className="text-white/30 text-[10px] tracking-widest uppercase mb-3 px-2">Settings</p>
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm transition-all"
            style={{
              background: tab === t.id ? "rgba(0,229,255,0.1)" : "transparent",
              color: tab === t.id ? "#00e5ff" : "rgba(255,255,255,0.5)",
              border: tab === t.id ? "1px solid rgba(0,229,255,0.2)" : "1px solid transparent",
            }}
          >
            <span>{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}

        <div className="flex-1" />
        <button
          onClick={onLogout}
          className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-red-400/70 hover:bg-red-500/10 transition-colors"
        >
          <span>⏻</span>
          <span>Sign Out</span>
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto os-scrollbar p-6">
        {tab === "appearance" && (
          <div className="space-y-8 max-w-lg">
            <div>
              <h2 className="text-lg font-bold mb-1" style={{ fontFamily: "'Orbitron', sans-serif" }}>Appearance</h2>
              <p className="text-white/30 text-sm">Customize the look of your NovOS</p>
            </div>

            {/* Wallpaper */}
            <section>
              <h3 className="text-white/60 text-xs tracking-widest uppercase mb-3">Wallpaper</h3>
              <div className="grid grid-cols-3 gap-3">
                {WALLPAPERS.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => update({ wallpaper: w.id })}
                    className="relative rounded-xl overflow-hidden aspect-video border-2 transition-all"
                    style={{
                      background: w.preview,
                      borderColor: settings.wallpaper === w.id ? "#00e5ff" : "transparent",
                      boxShadow: settings.wallpaper === w.id ? "0 0 12px rgba(0,229,255,0.5)" : "none",
                    }}
                  >
                    {settings.wallpaper === w.id && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-white text-lg drop-shadow">✓</span>
                      </div>
                    )}
                    <span className="absolute bottom-1 left-0 right-0 text-center text-[9px] text-white/70">{w.name}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Accent Color */}
            <section>
              <h3 className="text-white/60 text-xs tracking-widest uppercase mb-3">Accent Color</h3>
              <div className="flex gap-3 flex-wrap">
                {ACCENT_COLORS.map((a) => (
                  <button
                    key={a.color}
                    onClick={() => update({ accentColor: a.color })}
                    className="w-8 h-8 rounded-full border-2 transition-all hover:scale-110"
                    style={{
                      background: a.color,
                      borderColor: settings.accentColor === a.color ? "white" : "transparent",
                      boxShadow: settings.accentColor === a.color ? `0 0 12px ${a.color}` : "none",
                    }}
                    title={a.name}
                  />
                ))}
              </div>
            </section>

            {/* Display Name */}
            <section>
              <h3 className="text-white/60 text-xs tracking-widest uppercase mb-3">Display Name</h3>
              <div className="flex gap-2">
                <input
                  value={localName}
                  onChange={(e) => setLocalName(e.target.value)}
                  className="flex-1 bg-white/5 border border-cyan-500/20 rounded-xl px-4 py-2.5 text-white/80 outline-none focus:border-cyan-400/40 transition-all text-sm"
                  placeholder="Your name"
                />
                <button
                  onClick={() => update({ userName: localName })}
                  className="px-4 py-2.5 rounded-xl bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 text-sm hover:bg-cyan-500/30 transition-colors"
                >
                  Save
                </button>
              </div>
            </section>
          </div>
        )}

        {tab === "system" && (
          <div className="space-y-8 max-w-lg">
            <div>
              <h2 className="text-lg font-bold mb-1" style={{ fontFamily: "'Orbitron', sans-serif" }}>System</h2>
              <p className="text-white/30 text-sm">Clock, display, and system settings</p>
            </div>

            {/* Clock Format */}
            <section>
              <h3 className="text-white/60 text-xs tracking-widest uppercase mb-3">Clock Format</h3>
              <div className="flex gap-3">
                {(["12", "24"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => update({ clockFormat: f })}
                    className="px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
                    style={{
                      background: settings.clockFormat === f ? "rgba(0,229,255,0.2)" : "rgba(255,255,255,0.05)",
                      border: `1px solid ${settings.clockFormat === f ? "rgba(0,229,255,0.5)" : "rgba(255,255,255,0.1)"}`,
                      color: settings.clockFormat === f ? "#00e5ff" : "rgba(255,255,255,0.5)",
                    }}
                  >
                    {f}-hour
                  </button>
                ))}
              </div>
            </section>

            {/* Show seconds */}
            <section>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-white/80 text-sm font-medium">Show Seconds</h3>
                  <p className="text-white/30 text-xs mt-0.5">Display seconds in the top bar clock</p>
                </div>
                <button
                  onClick={() => update({ showSeconds: !settings.showSeconds })}
                  className="relative w-11 h-6 rounded-full transition-all"
                  style={{
                    background: settings.showSeconds ? "rgba(0,229,255,0.6)" : "rgba(255,255,255,0.1)",
                    border: `1px solid ${settings.showSeconds ? "rgba(0,229,255,0.8)" : "rgba(255,255,255,0.2)"}`,
                  }}
                >
                  <div
                    className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all"
                    style={{ left: settings.showSeconds ? "calc(100% - 22px)" : "2px" }}
                  />
                </button>
              </div>
            </section>

            {/* Account */}
            <section>
              <h3 className="text-white/60 text-xs tracking-widest uppercase mb-3">Account</h3>
              <div className="glass-light rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center text-lg">
                  {user.name[0]?.toUpperCase()}
                </div>
                <div>
                  <p className="text-white/80 text-sm font-medium">{user.name}</p>
                  <p className="text-white/40 text-xs">{user.email}</p>
                  {user.isAdmin && (
                    <span className="text-[10px] text-cyan-400 font-semibold tracking-wider">ADMINISTRATOR</span>
                  )}
                </div>
              </div>
            </section>
          </div>
        )}

        {tab === "about" && (
          <div className="space-y-6 max-w-lg">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center text-3xl animate-float">
                ✦
              </div>
              <div>
                <h1 className="text-2xl font-black text-white" style={{ fontFamily: "'Orbitron', sans-serif" }}>NovOS</h1>
                <p className="text-white/40 text-sm">Version 1.0.0 · Build 2025</p>
              </div>
            </div>

            <div className="space-y-3">
              {[
                ["Platform", "Web / PWA"],
                ["Engine", "Chromium / Gecko"],
                ["Framework", "React 19"],
                ["Release", "September 2025"],
                ["License", "Proprietary"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between py-3 border-b border-white/5">
                  <span className="text-white/40 text-sm">{k}</span>
                  <span className="text-white/70 text-sm font-medium">{v}</span>
                </div>
              ))}
            </div>

            <p className="text-white/30 text-xs leading-relaxed">
              NovOS is a next-generation web operating system built for the future. Customizable, powerful, and always evolving.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
