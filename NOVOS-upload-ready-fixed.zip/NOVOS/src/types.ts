export interface OSUser {
  email: string;
  name: string;
  isAdmin: boolean;
}

export interface OSApp {
  id: string;
  name: string;
  icon: string;
  description: string;
  category: string;
  builtIn: boolean;
  adminOnly?: boolean;
  type: "builtin" | "url" | "html";
  url?: string;
  code?: string;
  installed?: boolean;
  version?: string;
  author?: string;
  rating?: number;
  downloads?: number;
}

export interface OSWindow {
  id: string;
  appId: string;
  title: string;
  icon: string;
  x: number;
  y: number;
  width: number;
  height: number;
  minimized: boolean;
  maximized: boolean;
  zIndex: number;
}

export interface OSSettings {
  wallpaper: string;
  accentColor: string;
  userName: string;
  clockFormat: "12" | "24";
  showSeconds: boolean;
}

export interface CustomDomain {
  domain: string;
  url: string;
  title: string;
}

export type AppCategory = "Productivity" | "Entertainment" | "Utilities" | "Developer" | "Social" | "Education";
