# NOVOS download page plan

Supported choices:
- Windows — NOVOS-Setup.exe
- Linux — NOVOS.AppImage
- macOS — NOVOS.dmg
- Android — NOVOS.apk
- iOS — native iOS build / IPA for permitted distribution
- ChromeOS — NOVOS web/PWA

The repository contains the download-center UI, but the binary files must be built first and then uploaded to your chosen host.
