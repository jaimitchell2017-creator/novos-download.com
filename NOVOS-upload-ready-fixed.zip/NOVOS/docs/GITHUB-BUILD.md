# NOVOS GitHub build automation

This repository includes a GitHub Actions workflow at `.github/workflows/build-release.yml`.

## What it builds

- Windows: `NOVOS-Setup.exe`
- Linux: `NOVOS.AppImage`
- macOS: `NOVOS.dmg`
- Android: `NOVOS.apk`
- iOS: an **unsigned simulator build** (`NOVOS-iOS-unsigned.zip`). A public/installable iPhone release still requires Apple's signing/distribution process.

## How to start a release

1. Upload the complete NOVOS source to a GitHub repository.
2. Create and push a tag such as `v1.0.0`.
3. GitHub Actions builds the packages on Windows, Ubuntu and macOS runners.
4. The workflow publishes the successful packages to a GitHub Release.

The workflow also supports `workflow_dispatch` for testing the build without publishing a release.

## ChromeOS

ChromeOS does not have one universal NOVOS native installer format. A Chromebook that supports Android apps can use the APK; a Chromebook with Linux development environment enabled can use the Linux build when the desktop environment supports it. The normal NOVOS web/PWA remains the broadest ChromeOS option.
